var Main = /** @class */ (function () {
    function Main() {
    }
    Main.prototype.main = function () {
        console.log("Mensaje desde Main");
        var usuarios;
        usuarios = new Array();
        usuarios.push(new User(1, "Mariano", "mariano@gmail.com"));
        usuarios.push(new User(2, "Juan", "juan@gmail.com"));
        usuarios.push(new User(3, "Pedro", "pedro@gmail.com"));
        this.mostrarUsers(usuarios);
        this.myf = new MyFramework();
        var b = document.getElementById("boton");
        b.addEventListener("click", this);
        this.myf.requestGET('devices.txt', this);
    };
    Main.prototype.mostrarUsers = function (users) {
        for (var i in users) {
            users[i].printInfo();
        }
    };
    Main.prototype.handleEvent = function (evt) {
        console.log("Se hizo click");
        console.log(this);
    };
    Main.prototype.handleGETResponse = function (status, response) {
        console.log("Respujesta del servidor: " + response);
        var data = JSON.parse(response);
        console.log(data);
    };
    return Main;
}());
window.onload = function () {
    var m = new Main();
    m.main();
};
//=======[ Settings, Imports & Data ]==========================================
var user = "TypesScript Users!";
//=======[ Main module code ]==================================================
function greeter(person) {
    return "Hello, " + person;
}
//document.body.innerHTML = greeter(user);
console.log("Hola mundo!");
//=======[ End of file ]=======================================================
