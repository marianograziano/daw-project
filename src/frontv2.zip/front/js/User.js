var User = /** @class */ (function () {
    function User(id, name, email) {
        this._id = id;
        this._name = name;
        this._email = email;
    }
    Object.defineProperty(User.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (id) {
            this._id = id;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (name) {
            this._name = name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(User.prototype, "email", {
        get: function () {
            return this._email;
        },
        set: function (email) {
            this._email = email;
        },
        enumerable: true,
        configurable: true
    });
    User.prototype.printInfo = function () {
        console.log("id = " + this._id + ", name = " + this._name + ", email = " + this._email);
    };
    return User;
}());
