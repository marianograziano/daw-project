class Framework{
    getElementById(id:string):HTMLElement
    {
        let e:HTMLElement;
        e = document.getElementById(id);
        return e;
    }
    changeText(id:string):void{
        let e:HTMLElement;
        e = document.getElementById(id);
        e.innerText  = "Texto de Boton Cambiado";
    }
    getelementbyEvent(evt:Event):HTMLElement{
        
        return <HTMLElement>evt.target //No es un html puro y duro

    }

}

