var Main = /** @class */ (function () {
    function Main() {
        this.counter = 0;
    }
    Main.prototype.main = function () {
        console.log("estoy en main()");
        var usuarios;
        usuarios = new Array();
        usuarios.push(new User(1, "Mariano", "mariano@gmail.com"));
        usuarios.push(new User(2, "Juan", "juan@gmail.com"));
        usuarios.push(new User(3, "Pedro", "pedro@gmail.com"));
        this.mostrarUsers(usuarios);
        this.myf = new MyFramework();
        this.view = new ViewMainPage(this.myf); // Encapsular todo lo que es front 
        this.myf.configEventLister("click", "boton", this);
        this.myf.requestGET("http://localhost:8000/dispositivos", this);
    };
    Main.prototype.mostrarUsers = function (users) {
        //    for (let i in users)
        //    {
        //        users[i].printInfo ();
        //    }
        //    {
        //        o.printInfo ();
        //     }
    };
    Main.prototype.handleEvent = function (evt) {
        console.log("se hizo \"" + evt.type + "\"");
        var b = this.myf.getElementByEvent(evt); // QUE ELEMENTO ORigino el evento.
        console.log(b);
        if (b.id == "boton") {
            this.counter++;
            b.textContent = "Click " + this.counter;
        }
        else {
            var state = this.view.getSwitchStateById(b.id);
            var data = { "id": "" + b.id, "state": state };
            this.myf.requestPOST("https://cors-anywhere.herokuapp.com/https://postman-echo.com/post", data, this);
            //this.myf.requestPOST ("Devices.php", data, this);
        }
    };
    Main.prototype.handleGETResponse = function (status, response) {
        console.log("Respuesta del servidor: " + response);
        var data = JSON.parse(response);
        console.log(data);
        this.view.showDevices(data);
        for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
            var d = data_1[_i];
            var b = this.myf.getElementById("dev_" + d.id);
            b.addEventListener("click", this);
        }
    };
    Main.prototype.handlePOSTResponse = function (status, response) {
        console.log(status);
        console.log(response);
    };
    return Main;
}());
window.onload = function () {
    var m = new Main();
    m.main();
};
//=======[ Settings, Imports & Data ]==========================================
var user = "TypesScript Users!";
//=======[ Main module code ]==================================================
function greeter(person) {
    return "Hello, " + person;
}
// document.body.innerHTML = greeter(user);
console.log("Hola mundo!");
//=======[ End of file ]=======================================================
