var MyFramework = /** @class */ (function () {
    function MyFramework() {
    }
    MyFramework.prototype.getElementById = function (id) {
        var e;
        e = document.getElementById(id);
        return e;
    };
    MyFramework.prototype.getElementByEvent = function (evt) {
        return evt.target;
    };
    MyFramework.prototype.requestGET = function (url, listener) {
        var xhr;
        xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    listener.handleGETResponse(xhr.status, xhr.responseText);
                }
                else {
                    listener.handleGETResponse(xhr.status, null);
                }
            }
        };
        xhr.open('GET', url, true);
        xhr.send(null);
    };
    MyFramework.prototype.requestPOST = function (url, data, listener) {
        var xhr;
        xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    listener.handlePOSTResponse(xhr.status, xhr.responseText);
                }
                else {
                    listener.handlePOSTResponse(xhr.status, null);
                }
            }
        };
        xhr.open('POST', url);
        // envio JSON en body de request (Usar con NODEJS)
        xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        xhr.send(JSON.stringify(data));
        //______________________________
        // envio Formdata en body de request (Usar con Apache,PythonWS,etc.)
        //let formData:FormData = new FormData();
        //for (let key in data) {
        //formData.append(key, data[key]);
        //}
        //xhr.send(formData);
        //______________________________
    };
    MyFramework.prototype.configEventLister = function (event, id, listener) {
        var b = document.getElementById(id);
        b.addEventListener(event, listener);
    };
    return MyFramework;
}());
