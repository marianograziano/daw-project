var Main2 = /** @class */ (function () {
    function Main2() {
        this.texto = "Esto es un texto";
    }
    Main2.prototype.handleEvent = function (evt) {
        console.log("se hizo click! -interface-");
        console.log(this);
        this.frame.getelementbyEvent(evt);
    };
    Main2.prototype.mostrarUsers = function (users) {
        for (var _i = 0, users_1 = users; _i < users_1.length; _i++) {
            var o = users_1[_i];
            o.printInfo();
        }
    };
    Main2.prototype.ppal = function () {
        console.log(this.texto);
        var a_usuarios;
        a_usuarios = new Array();
        a_usuarios.push(new Usuarios(1, "Usuario 1", "uno@gmail.com"));
        a_usuarios.push(new Usuarios(2, "Usuario 2", "dos@gmail.com"));
        a_usuarios.push(new Usuarios(3, "Usuario 3", "treso@gmail.com"));
        this.mostrarUsers(a_usuarios);
        this.frame = new Framework();
        var b = this.frame.getElementById("boton");
        console.log(b.textContent);
        b.addEventListener('click', this);
    };
    return Main2;
}());
window.onload = function () {
    var m = new Main2();
    m.ppal();
};
