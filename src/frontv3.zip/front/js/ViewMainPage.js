var ViewMainPage = /** @class */ (function () {
    function ViewMainPage(myf) {
        this.myf = myf;
    }
    ViewMainPage.prototype.showDevices = function (list) {
        var e = this.myf.getElementById("devicesList"); // obtengo el lugar adonde tengo que agregar 
        for (var _i = 0, list_1 = list; _i < list_1.length; _i++) {
            var dev = list_1[_i];
            var image = 'lightbulb.png';
            if (dev.type == 1) {
                image = 'window.png';
            }
            var checked = '';
            if (dev.type == 1) {
                checked = 'checked';
            }
            e.innerHTML += "<li class=\"collection-item avatar\">\n                                <img src=\"static/images/" + image + "\" alt=\"\" class=\"circle\">\n                                <span class=\"title\">" + dev.name + "</span>\n                                <p>" + dev.description + "</p>\n                                <a href=\"#!\" class=\"secondary-content\">\n                                    <div class=\"switch\">\n                                        <label>\n                                        Off\n                                        <input id=\"dev_" + dev.id + "\" type=\"checkbox\" " + checked + "> <!-- id para controlar el switch --!>\n                                        <span class=\"lever\"></span>\n                                        On\n                                        </label>\n                                    </div>\n                                </a>\n                            </li>";
        }
    };
    ViewMainPage.prototype.getSwitchStateById = function (id) {
        var e = this.myf.getElementById(id);
        var i = e; // se castea para ver el estado del id
        return i.checked; // al ser un input puedo ver si esta tildado.
    };
    return ViewMainPage;
}());
