var Framework = /** @class */ (function () {
    function Framework() {
    }
    Framework.prototype.getElementById = function (id) {
        var e;
        e = document.getElementById(id);
        return e;
    };
    Framework.prototype.changeText = function (id) {
        var e;
        e = document.getElementById(id);
        e.innerText = "Texto de Boton Cambiado";
    };
    Framework.prototype.getelementbyEvent = function (evt) {
        return evt.target; //No es un html puro y duro
    };
    return Framework;
}());
